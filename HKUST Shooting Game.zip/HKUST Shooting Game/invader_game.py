#Name: Darshna Girish Sadhnani
#Student ID: 20473564

import turtle


"""
    Constants and variables
"""
turtle.hideturtle()

# General parameters
window_height = 600
window_width = 600
window_margin = 50
update_interval = 25    # The screen update interval in ms, which is the
                        # interval of running the updatescreen function

# Player's parameters
player_size = 50        # The size of the player image plus margin
player_init_x = 0
player_init_y = (-window_height / 2 + window_margin)
player_speed = 10       # The speed the player moves left or right

# Enemy's parameters
enemy_number = 25        # The number of enemies in the game

enemy_size = 56         # The size of the enemy image plus margin
enemy_init_x = -window_width / 2 + window_margin
enemy_init_y = (window_height / 2 - window_margin)-100
enemy_min_x = enemy_init_x
enemy_max_x = window_width / 2 - enemy_size
    # The maximum x coordinate of the first enemy, which will be used
    # to restrict the x coordinates of all other enemies
enemy_kill_player_distance = 30
    # The player will lose the game if the vertical
    # distance between the enemy and the player is smaller
    # than this value

# Enemy movement parameters
enemy_speed = 2
enemy_speed_increment = 1
    # The increase in speed every time the enemies move
    # across the window and back
enemy_direction = 1
bonus_enemy_direction=1
    # The current direction the enemies are moving:
    #     1 means from left to right and
    #     -1 means from right to left

# The list of enemies
enemies = []

#label for score number
score_number_text = turtle.Turtle()
score_number_text.hideturtle()

bonus_enemy=turtle.Turtle()
bonus_enemy.hideturtle()


# Laser parameter
laser_width = 2
laser_height = 15
laser_speed = 20
laser_kill_enemy_distance = 20
    # The laser will destory an enemy if the distance
    # between the laser and the enemy is smaller than
    # this value

#score parameters
score=0
cheat_press= False
bonus_x=300
flag=1
bonus_enemy_interval=8000
bonus_dx=0


turtle.update()

"""
    Handle the player movement
"""

def cheat():
    global cheat_press
    if cheat_press:
        cheat_press= False
    else:
        cheat_press= True
    

# This function is run when the "Left" key is pressed. The function moves the
# player to the left when the player is within the window area
def playermoveleft():
    # Get current player position
    x, y = player.position()

    # Part 2.2 - Keeping the player inside the window
    # Player should only be moved only if it is within the window range
    if x - player_speed > -window_width / 2 + window_margin:
            player.goto(x - player_speed, y)

    
    turtle.update() # delete this line after finishing updatescreen()

# This function is run when the "Right" key is pressed. The function moves the
# player to the right when the player is within the window area
def playermoveright():

    # Get current player position
    x, y = player.position()

    # Part 2.2 - Keeping the player inside the window
    # Player should only be moved only if it is within the window range
    if x + player_speed < window_width / 2 - window_margin:
        player.goto(x + player_speed, y)
    

    turtle.update() # delete this line after finishing updatescreen()

"""
    Handle the screen update and enemy movement
"""

# This function is run in a fixed interval. It updates the position of all
# elements on the screen, including the player and the enemies. It also checks
# for the end of game conditions.
def updatescreen():
    # Use the global variables here because we will change them inside this
    # function
    global enemy_direction, enemy_speed,bonus_x,bonus_enemy_direction,flag,score,bonus_dx
    turtle.hideturtle(),score_number_text,bonus_enemy,cheat_press
    #bonusenemy()

    # Move the enemies depending on the moving direction

    # The enemies can only move within an area, which is determined by the
    # position of enemy at the top left corner, enemy_min_x and enemy_max_x

    # x and y displacements for all enemies
    bonus_dx=2*bonus_enemy_direction
    if cheat_press == False:
        dx = enemy_speed * enemy_direction
        bonus_dx=2*bonus_enemy_direction
        bonus_enemy.showturtle()
    else:
        dx=0
        bonus_dx=0
    
    
    dy = 0

    # Part 3.3
    # Perform several actions if the enemies hit the window border

    x0 = enemies[0].xcor()
    bonus_x= bonus_enemy.position()[0]
    if(len(enemies)>7):
        x1=enemies[6].xcor()
    else:
        x1 = enemies[len(enemies)-1].xcor()

        
    if x1 + dx > enemy_max_x or x0 + dx < enemy_min_x:
        # Switch the moving direction
        enemy_direction = -enemy_direction

        # Bring the enemies closer to the player
        dy = -enemy_size/2

        # Increase the speed when the direction switches to right again
        if enemy_direction == 1:
            enemy_speed = enemy_speed + enemy_speed_increment

    # Move the enemies according to the dx and dy values determined above
    for enemy in enemies:
        x = enemy.position()[0]
        
        y = enemy.position()[1]

        if(x//20)%2==0:
            enemy.shape("enemy1.gif")
        else:
            enemy.shape("enemy2.gif")
            
        enemy.goto(x + dx, y + dy)
        
        
        if(bonus_enemy.xcor()<-250):
            bonus_enemy_direction=-1
        if(bonus_enemy.xcor()>250):
            bonus_enemy_direction=1
            flag=0
            
        if(bonus_enemy_direction>0):
            bonus_enemy.showturtle()

        if(bonus_enemy_direction<0 or flag==1):
            bonus_enemy.hideturtle()
            
    bonus_enemy.goto(bonus_x - bonus_dx,250)
            
    
        
    

    # Part 4.3 - Moving the laser
    # Perform several actions if the laser is visible
    turtle.onkeypress(shootlaser, "space")

    if laser.isvisible():
        # Move the laser
        laser.forward(laser_speed)
        
        # Hide the laser if it goes beyond the window
        if laser.ycor() >= window_height / 2:
            laser.hideturtle()

        # Check the laser against every enemy using a for loop
        for enemy in enemies:
            # If the laser hits a visible enemy, hide both of them
            if enemy.isvisible() and laser.distance(enemy) <= laser_kill_enemy_distance:
                laser.hideturtle()
                enemy.hideturtle()
                score=score+20
                score_number_text.clear()
                score_number_text.write("SCORE: "+ str(score), font=("System", 10, "bold"), align="center")
                # Stop if some enemy is hit
                break
            
        if bonus_enemy.isvisible() and laser.distance(bonus_enemy)<= laser_kill_enemy_distance:
            laser.hideturtle()
            bonus_enemy.hideturtle()
            flag=1
            bonus_enemy_interval=3000
            score=score+100
            
            #label for enemies number
            score_number_text.clear()
            score_number_text.up()
            score_number_text.write("SCORE: "+str(score), font=("System", 10, "bold"), align="center")

                

    # Part 5.1 - Gameover when one of the enemies is close to the player

    # If one of the enemies is very close to the player, the game will be over
    for enemy in enemies:
        if (enemy.ycor()-player.ycor() <= enemy_kill_player_distance  and enemy.isvisible()):
            # Show a message
            gameover("You have stress!!")

            # Return and do not run updatescreen() again
            return

    # Part 5.2 - Gameover when  killed all enemies

    # Set up a variable as a counter
    count = 0

    # For each enemy
    for enemy in enemies:
        if enemy.isvisible():
            count += 1

        # Increase the counter if the enemy is visible

    # If the counter is 0, that means you have killed all enemies
    if count == 0:
        gameover("Hooray! You are stress-free")

        # Perform several gameover actions
        return
    
    # Part 3.2 - Controlling animation using the timer event

    # Update the screen
    turtle.update()

    # Schedule the next screen update
    turtle.ontimer(updatescreen, update_interval)





    
"""
    Shoot the laser
"""

# This function is run when the player presses the spacebar. It shoots a laser
# by putting the laser in the player's current position. Only one laser can
# be shot at any one time.
def shootlaser():

    #print("Pyoo!") # delete this line after completing the function

    # Part 4.2 - the shooting function
    # Shoot the laser only if it is not visible

    if laser.isvisible() == False:
        # Make the laser to become visible
        laser.showturtle()

        # Move the laser to the position of the player
        laser.goto(player.xcor(),player.ycor())
        
        

"""
    Game start
"""
# This function contains things that have to be done when the game starts.
def gamestart(x,y):
    global start_button
    start_button.clear()
    start_button.hideturtle()
    labels.clear()
    enemy_number_text.clear()
    left_arrow.hideturtle()
    right_arrow.hideturtle()
    turtle.hideturtle()
    instructions.clear()
    title.clear()

    #setup the bonusenemy turtle
    turtle.addshape("bonusenemy.gif")
    bonus_enemy.shape("bonusenemy.gif")

    bonus_enemy.up()
    bonus_enemy.goto(300,250)

    score_number_text.up()
    score_number_text.goto(-250,250)
    score_number_text.color("black")
    
    # Use the global variables here because we will change them inside this
    # function
    global player, laser

    ### Player turtle ###

    # Add the spaceship picture
    turtle.addshape("HKUST_bird.gif")

    # Create the player turtle and move it to the initial position
    player = turtle.Turtle()
    player.shape("HKUST_bird.gif")
    player.up()
    player.goto(player_init_x, player_init_y)

    # Part 2.1
    # Map player movement handlers to key press events

    turtle.onkeypress(playermoveleft,"Left")
    turtle.onkeypress(playermoveright, "Right")

    turtle.listen()

    ### Enemy turtles ###

    # Add the enemy picture
    turtle.addshape("enemy1.gif")
    turtle.addshape("enemy2.gif")
    #turtle.addshape("bonus_enemy")

    for i in range(enemy_number):
        # Create the turtle for the enemy
        enemy = turtle.Turtle()
        enemy.shape("enemy1.gif")
        enemy.up()

        # Move to a proper position counting from the top left corner
        enemy.goto(enemy_init_x + enemy_size * (i % 7), enemy_init_y - enemy_size * (i // 7))

        # Add the enemy to the end of the enemies list
        enemies.append(enemy)

    ### Laser turtle ###

    # Create the laser turtle using the square turtle shape
    laser = turtle.Turtle()
    turtle.addshape("laser.gif")
    laser.shape("laser.gif")
    

    # Change the size of the turtle and change the orientation of the turtle
    laser.shapesize(laser_width / 20, laser_height / 20)
    laser.left(90)
    laser.up()

    # Hide the laser turtle
    laser.hideturtle()

    # Part 4.2 - Mapping the shooting function to key press event

    #
    # Add code here
    #

    turtle.update()

    # Part 3.2 - Controlling animation using the timer event

    # start the game by running updatescreen()
    turtle.ontimer(updatescreen, update_interval)

turtle.tracer(False)
#Putting gamestart function in onclick handler. 
start_button = turtle.Turtle()
start_button.onclick(gamestart)

#putting a cheat key function for the enemies
turtle.onkeypress(cheat,key="c")
turtle.listen()

# Set up the start_button
start_button.up()
start_button.goto(-40, -40)
start_button.color("white", "DarkGray")
start_button.begin_fill()
for _ in range(2):
    start_button.forward(80)
    start_button.left(90)
    start_button.forward(25)
    start_button.left(90)
start_button.end_fill()

# Set up other controls
start_button.color("white")
start_button.goto(0, -35)
start_button.write("Start", font=("System", 12, "bold"), align="center")

start_button.goto(0,-28)
start_button.shape("square")
start_button.shapesize(1.25,4)
start_button.color("")


#GUI componetents go here
#3.1 create a text label
labels = turtle.Turtle()
labels.color("black")
labels.hideturtle()
labels.up()
labels.goto(-100,0)
labels.write("Number of Enemies:", font=("System", 10, "bold"))

#create title label
title = turtle.Turtle()
title.color("black")
title.hideturtle()
title.up()
labels.goto(-200,200)
labels.write("HKUST SHOOTING GAME!!", font=("System", 20, "bold"))

#Create instructions labels
instructions = turtle.Turtle()
instructions.color("black")
instructions.hideturtle()
instructions.up()
instructions.goto(-280,150)
instructions.write("1.Choose the number of enemies that you want and click on the start button", font=("System",10))
instructions.goto(-280,125)
instructions.write("2.use the arrow keys to move the player. Click on space bar to shoot", font=("System",10))
instructions.goto(-280,100)
instructions.write("3. If you shoot the enemies, you will get 20 points.", font=("System",10))
instructions.goto(-280,75)
instructions.write("4. If you shoot the bonus enemy , you will get 100 points.", font=("System",10))
instructions.goto(-280,50)
instructions.write("5.It appears every 5-10 seconds.", font=("System",10))
instructions.goto(-280,25)
instructions.write("6.If you shoot all the books/shirts, you will be stress-free or else you will have stress!", font=("System",10))



#label for enemies number
enemy_number_text = turtle.Turtle()
enemy_number_text.hideturtle()
enemy_number_text.up()
enemy_number_text.goto(80,0)
enemy_number_text.color("white")
enemy_number_text.write(str(enemy_number), font=("System", 10, "bold"), align="center")

left_arrow=turtle.Turtle()
left_arrow.shape("arrow")
left_arrow.color("white")
left_arrow.shapesize(0.5,1)
left_arrow.left(180)
left_arrow.up()
left_arrow.goto(60,8)


def decrease_enemy_number(x, y):
    global enemy_number
    global enemy_number_text
    if enemy_number > 1 :
        enemy_number=enemy_number-1
        enemy_number_text.clear()
        enemy_number_text.write(str(enemy_number), font=("System", 10, "bold"), align="center")
        
left_arrow.onclick(decrease_enemy_number)

right_arrow=turtle.Turtle()
right_arrow.shape("arrow")
right_arrow.color("white")
right_arrow.shapesize(0.5,1)
right_arrow.up()
right_arrow.goto(100,8)

def increase_enemy_number(x, y):
    global enemy_number
    global enemy_number_text
    if enemy_number < 49 :
        enemy_number=enemy_number+1
        enemy_number_text.clear()
        enemy_number_text.write(str(enemy_number), font=("System", 10, "bold"), align="center")

right_arrow.onclick(increase_enemy_number)
"""
    Game over
"""

# This function shows the game over message.
def gameover(message):

    # Part 5.3 - Improving the gameover() function

    gameover_turtle = turtle.Turtle()
    gameover_turtle.hideturtle()
    gameover_turtle.pencolor("red")
    gameover_turtle.write(message, align="center", font=("System", 30, "bold"))

    turtle.update()

"""
    Set up main Turtle parameters
"""

# Set up the turtle window
turtle.setup(window_width, window_height)
turtle.bgpic("Background.gif")
turtle.up()
turtle.hideturtle()
turtle.tracer(False)


# Switch focus to turtle graphics window
turtle.done()
